#ifndef _LIBGEN_H
#define _LIBGEN_H

#ifdef __cplusplus
extern "C" {
#endif

char *dirname(char *);
char *basename(char *);

#ifdef __cplusplus
}
#endif

#endif
